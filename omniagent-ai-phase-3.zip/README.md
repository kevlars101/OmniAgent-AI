# OmniAgent AI

Phase 2 scaffold for the OmniAgent AI backend and RAG pipeline.

## Current Phase

Implemented:

- FastAPI app factory with versioned routing.
- Async SQLAlchemy database session setup.
- Local development auth boundary ready for Clerk JWT verification in a later phase.
- PDF/DOCX document ingestion.
- Paragraph-aware chunking.
- Gemini embeddings by default, with OpenAI and local deterministic stub support.
- Persistent ChromaDB vector store.
- Semantic search with a lexical boost baseline for hybrid retrieval.
- LangGraph workflow orchestration across planning, research, coding, report, and presentation agents.

## Run Backend Locally

```bash
cd backend
python -m venv .venv
.venv\Scripts\activate
pip install -e .
uvicorn app.main:app --reload
```

Copy `.env.example` to `.env` before running and adjust provider keys as needed.
